#ifndef PIC_HASH_COMPUTE_H
#define PIC_HASH_COMPUTE_H

void compute_hash(unsigned char *inp, unsigned char *out);

#endif
